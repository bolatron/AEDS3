#include "prototype.h"

float **somatorioMatriz(int **arr, float **mask, int *flag, int size_mask, int size_res) {
    int i, j, l, k, flag1 = 1;
    float **arr_res = (float**) malloc(size_res*sizeof(float*));
    for(i=0; i < size_res; i++)
        arr_res[i] = (float*) malloc(size_res*sizeof(float));
    for(i=0; i < size_res; i++){
        for(j=0; j < size_res; j++){
            for(l=0; l < size_mask; l++){
                for(k=0; k < size_mask; k++){
                    arr_res[j][i] += (arr[l+j][k+i] * mask[l][k]);
                }
            }
            if(arr_res[j][i] == 1.00 && flag1){
                flag1 = 0;
                *flag = 1 - *flag;
            }
        }
    }
    return arr_res;
}

int achaMaiorMatrizPorMascara_Iterativo(int **arr, int sizeM) {
    int i, j, iter, flag = 1;
    int size_mask = sizeM, size_res = 1;
    for(iter=0; iter < sizeM + 1 && flag; iter++){
        float **mask = (float**) malloc(size_mask*sizeof(float*));
        float **res_arr = (float**) malloc(size_res*sizeof(float*));
        for(i=0; i < size_res; i++)
            res_arr[i] = (float*) malloc(size_res*sizeof(float));
        for(i=0; i < size_mask; i++)
            mask[i] = (float*) malloc(size_mask*sizeof(float));
        for(i=0; i < size_mask; i++)
            for(j=0; j < size_mask; j++)
                mask[i][j] = (float)1/(size_mask*size_mask); //Grau de ativação para cada elemento da mascara
        res_arr = somatorioMatriz(arr, mask, &flag, size_mask, size_res);
        //printaMatrizfloat(res_arr, size_res, sizeM);
        if(flag == 0)
            printaMaiorMatrizMascara(arr, res_arr, size_res, size_mask);
        liberaMatrizfloat(res_arr, size_res);
        liberaMatrizfloat(mask, size_mask);
        size_res++;
        size_mask--;
    }
    return size_mask + 1;
}

int achaMaiorMatrizPorMascara_Recursivo(int **arr, int sizeM, int size_mask) {
    int i, j, flag = 0;
    int size_res = sizeM - size_mask + 1;
    if(size_mask <= 0)
        return 0;
    float **mask = (float**) malloc(size_mask*sizeof(float*));
    float **res_arr = (float**) malloc(size_res*sizeof(float*));
    for(i=0; i < size_res; i++)
        res_arr[i] = (float*) malloc(size_res*sizeof(float));
    for(i=0; i < size_mask; i++)
        mask[i] = (float*) malloc(size_mask*sizeof(float));
    for(i=0; i < size_mask; i++)
        for(j=0; j < size_mask; j++)
            mask[i][j] = (float)1/(size_mask*size_mask); //Grau de ativação para cada elemento da mascara
    res_arr = somatorioMatriz(arr, mask, &flag, size_mask, size_res);
    //printaMatrizfloat(res_arr, size_res, sizeM);
    liberaMatrizfloat(mask, size_mask);
    if(flag){
        printaMaiorMatrizMascara(arr, res_arr, size_mask, size_res);
        return size_mask;
    }
    liberaMatrizfloat(res_arr, size_res);
    achaMaiorMatrizPorMascara_Recursivo(arr, sizeM, size_mask - 1);
}

int GulosoVertical(int **arr, int size, int pos_i, int pos_j, int altura){
    if(pos_i < size - altura)
        if(arr[pos_i][pos_j])
            return 1 + GulosoVertical(arr, size, pos_i + 1, pos_j, altura);
    return 0;
}

int GulosoHorizontal(int **arr, int size, int pos_i, int pos_j, int altura){
    if(pos_j < size - altura)
        if(arr[pos_i][pos_j])
            return 1 + GulosoHorizontal(arr, size, pos_i, pos_j + 1, altura);
    return 0;
}

int GulosoDiagonal(int **arr, int size, int pos_i, int pos_j, int altura){
    int verifica = 0;
    if(pos_i < size && pos_j < size){
        if(arr[pos_i][pos_j]){
            if(altura == 1)
                return 1;
            if((altura - 1) == GulosoHorizontal(arr, size, pos_i, pos_j + 1, altura))
                if((altura - 1) == GulosoVertical(arr, size, pos_i + 1, pos_j, altura))
                    verifica = GulosoDiagonal(arr, size, pos_i + 1, pos_j + 1, altura - 1);
        }
    }
    return verifica;
}

int achaMaiorMatrizPorGuloso(int **arr, int size) {
    GulosoData data;
    int i, j, sizeH, sizeV, verifica = 0, altura = 0, altura_max = 1, pos_i=0, pos_j=0;
    for(i=0; i < size; i++){
        for(j=0; j < size; j++){
            if(arr[i][j]){
                sizeH = GulosoHorizontal(arr, size, i, j + 1, 0);
                sizeV = GulosoVertical(arr, size, i + 1, j, 0);
                altura = sizeV < sizeH ? sizeV : sizeH;
                //printf("sizeV = %d\nsizeH = %d\naltura = %d\n", sizeV, sizeH, altura);
                if(altura > 0)
                    verifica = GulosoDiagonal(arr, size, i + 1, j + 1, altura - 1);
            }
            if(verifica){
                if(altura_max < altura + 1){
                    altura_max = altura + 1;
                    pos_i = i;
                    pos_j = j;
                }
                verifica = 0;
            }
        }
    }
    data.pos_i = pos_i;
    data.pos_j = pos_j;
    data.altura_max = altura_max;
    printaMaiorMatrizGuloso(arr, size, data);
    return altura_max + 1;
}

int achaMaiorMatrizPorProgramacaoDinamica(int **arr, int size) {
    int i, j, sizeT = size + 1, max_submatrix = 0;
    int **arr_res = (int**) malloc(sizeT*sizeof(int*));
    for(i=0; i < sizeT; i++)
        arr_res[i] = (int*) malloc(sizeT*sizeof(int));
    for(i=0; i < sizeT; i++){
        for(j=0; j < sizeT; j++){
            if(i == 0 || j == 0)
                arr_res[i][j] = 0;
            else{
                if(arr[i-1][j-1])
                    arr_res[i][j] = min(arr_res[i-1][j], arr_res[i-1][j-1], arr_res[i][j-1]) + 1;
                else
                    arr_res[i][j] = 0;
            }
            if(arr_res[i][j] > max_submatrix)
                max_submatrix = arr_res[i][j];
        }
    }
    printaMaiorMatrizDinamico(arr, size, arr_res, max_submatrix);
    //printaMatrizInt(arr_res, sizeT);
    liberaMatrizInt(arr_res, sizeT);
    return max_submatrix;
}
