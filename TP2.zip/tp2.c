#include "prototype.h"

int main(int argc, char **argv) {
    int opt, size=0;
    int **arr;
    char *arquivo_entrada = NULL, *arquivo_saida = NULL;
    double utime, stime, total_time;
    while( (opt = getopt(argc, argv, "i:o:")) != -1) {
        switch ( opt ) {
            case 'i': // opção -i
                arquivo_entrada = optarg;
                arr = leMatrizDeEntrada(arquivo_entrada, &size);
                break ;
            case 'o': // opção -o
                arquivo_saida = optarg;
                break ;
            default:
                fprintf(stderr, "Opcao invalida ou faltando argumento: `%c'\n", optopt) ;
                return -1 ;
        }
    }
    //arr = geraMatrizAleatoria(4, 17);
    //arr = leMatrizDeEntrada(arquivo_entrada);
    printaMatrizInt(arr, size);
    /*for(seed=0; seed < iter; seed++){
        //printaMatrizInt(arr, size);
        //u[0] = achaMaiorMatrizPorMascara_Recursivo(arr, size, size);
        u[1] = achaMaiorMatrizPorGuloso(arr, size);
        //u[2] = achaMaiorMatrizPorMascara_Iterativo(arr, size);
        u[3] = achaMaiorMatrizPorProgramacaoDinamica(arr, size);
        //printf("%d\n%d\n%d\n", u[0], u[2], u[3]);
        /*if(u[0] != u[2] || u[2] != u[3] || u[0] != u[3])
            printf("Deu ruim na seed %d!\n", seed);
        if(u[1] == u[3])
            cont++;
        liberaMatrizInt(arr, size);
    }
    printf("%f\n", (float)cont/iter*100);*/
    //achaMaiorMatrizPorProgramacaoDinamica(arr, size);
    //achaMaiorMatrizPorGuloso(arr, size);
    /*printf("Teste para acha maior matriz por máscara(Força Bruta) recursivamente com %d amostras:\n", iter);
    for(i=0; i < iter; i++){
        achaMaiorMatrizPorMascara_Recursivo(arr, size, size);
        SystemUsage(&utime, &stime, &total_time);
        utimeAC += utime;
        stimeAC += stime;
        total_timeAC += total_time;
        utime = 0.000000;
        stime = 0.000000;
        total_time = 0.000000;
    }
    printf("Resultado usando média aritmética:\n");
    printf("User time %.3f, System time %.3f, Total Time %.3f\n\n", (double)utimeAC/iter, (double)stimeAC/iter, (double)total_timeAC/iter);
    printf("Teste para acha maior matriz por máscara(Força Bruta) iterativo com %d amostras:\n", iter);
    for(i=0; i < iter; i++){
        achaMaiorMatrizPorMascara_Iterativo(arr, size);
        SystemUsage(&utime, &stime, &total_time);
        utimeAC += utime;
        stimeAC += stime;
        total_timeAC += total_time;
        utime = 0.000000;
        stime = 0.000000;
        total_time = 0.000000;
    }
    printf("Resultado usando média aritmética:\n");
    printf("User time %.3f, System time %.3f, Total Time %.3f\n\n", (double)utimeAC/iter, (double)stimeAC/iter, (double)total_timeAC/iter);
    utimeAC = 0.000000;
    stimeAC = 0.000000;
    total_timeAC = 0.000000;*/
    //achaMaiorMatrizPorGuloso(arr, size);
    //printf("Maior tamanho: %d\n", achaMaiorMatrizPorProgramacaoDinamica(arr, size));
    //printaMatrizInt(arr, size);
    //achaMaiorMatrizPorProgramacaoDinamica(arr, size);
    //printaMatrizInt(arr, size);
    //SystemUsage(&utime, &stime, &total_time);
    //achaMaiorMatrizPorProgramacaoDinamica(arr, size);
    //achaMaiorMatrizPorProgramacaoDinamica(arr, size);
    //printaMatrizInt(arr, size);
    achaMaiorMatrizPorMascara_Recursivo(arr, size, size);
    printaMatrizInt(arr, size);
    //achaMaiorMatrizPorMascara_Iterativo(arr, size);
    //printaMatrizInt(arr, size);
    //achaMaiorMatrizPorMascara_Recursivo(arr, size, size);
    //printaMatrizInt(arr, size);
    escreveMatrizSaida(arr, size, arquivo_saida);
    SystemUsage(&utime, &stime, &total_time);
    printf("User time %.6f, System time %.6f, Total Time %.6f\n\n", utime, stime, total_time);
    liberaMatrizInt(arr, size);
    return 0;
}
