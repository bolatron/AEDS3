#include "prototype.h"

/* Gera uma matriz de inteiros 0 e 1, com base na seed dada */
int **geraMatrizAleatoria(int size, int seed) {
    srand(seed);
    int i, j;
    int **arr = (int**) malloc(size*sizeof(int*));
    for(i=0; i < size; i++)
        arr[i] = (int*) malloc(size*sizeof(int));
    for(i=0; i < size; i++)
        for(j=0; j < size; j++)
            arr[i][j] = rand()%2;
    return arr;
}

/* Função auxiliar da "geraMatrizAleatoria()", printa os elementos da matriz */
void printaMatrizInt(int **arr, int size) {
    int i, j;
    printf("Matriz gerada: \n");
    for(i=0; i < size; i++){
        for(j=0; j < size; j++)
            printf("%d ", arr[i][j]);
        printf("\n");
    }
    printf("\n");
}

void printaMatrizfloat(float **arr, int size, int sizeM){
    int i, j;
    printf("ativação em Mascara %d x %d:\n", (sizeM+1)-size, (sizeM+1)-size);
    for(i=0; i < size; i++){
        printf("[ ");
        for(j=0; j < size; j++)
            printf("%f ", arr[i][j]);
        printf("]\n");
    }
    printf("\n");
}

void printaTabela(int **arr, int size_i, int size_j) {
    int i, j;
    for(i=0; i < size_j; i++){
        for(j=0; j < size_i; j++)
            printf("%d ", arr[i][j]);
        printf("\n");
    }
    printf("\n");
}

void printaMaiorMatrizMascara(int **arr, float **res_arr, int size_res, int size_mask) {
    int i, j, k, l, sizeT = size_res + size_mask - 1;
    for(i=0; i < sizeT; i++)
        for(j=0; j < sizeT; j++)
            arr[i][j] = 0;
    //printaMatrizfloat(res_arr, size_res, sizeT);
    for(i=0; i < size_res; i++){
        for(j=0; j < size_res; j++){
            if(res_arr[i][j] == 1.00){
                for(k=0; k < size_mask; k++)
                    for(l=0; l < size_mask; l++)
                        arr[i+k][j+l] = 1;
            }
        }
    }
}

void printaMaiorMatrizGuloso(int **arr, int size, GulosoData data){
    int i, j, l, k;
    for(i=0; i < size; i++)
        for(j=0; j < size; j++)
            arr[i][j] = 0;
    for(i=0; i < size; i++){
        for(j=0; j < size; j++){
            if(data.pos_i == i && data.pos_j == j){
                for(k=0; k < data.altura_max; k++)
                    for(l=0; l < data.altura_max; l++)
                        arr[i+k][j+l] = 1;
            }
        }
    }
}

void printaMaiorMatrizDinamico(int **arr, int size, int **arr_res, int max_submatrix) {
    int i, j, l, k;
    for(i=0; i < size; i++)
        for(j=0; j < size; j++)
            arr[i][j] = 0;
        for(i=0; i < size + 1; i++){
            for(j=0; j < size + 1; j++){
                if(arr_res[i][j] == max_submatrix){
                    for(k=max_submatrix; k > 0; k--)
                        for(l=max_submatrix; l > 0; l--)
                            arr[i-k][j-l] = 1;
                }
            }
        }
}

void liberaMatrizInt(int **arr, int size) {
    int i;
    for(i=0; i < size; i++)
        free(arr[i]);
    free(arr);
}

void liberaMatrizfloat(float **arr, int size) {
    int i;
    for(i=0; i < size; i++)
        free(arr[i]);
    free(arr);
}

int min(int a, int b, int c) {
    int aux = a<b?a:b;
    return aux<c?aux:c;
}

void SystemUsage(double *utime, double *stime, double *total_time) {
    struct rusage resources;
    struct timeval tv;
    char buffer[30];
    time_t curtime;
    gettimeofday(&tv, NULL);
    int rc;
    if((rc = getrusage(RUSAGE_SELF, &resources)) != 0)
        perror("getrusage failed");
    curtime = tv.tv_sec;
    strftime(buffer,30,"%d-%m-%Y  %T.",localtime(&curtime));
    *utime = (float) resources.ru_utime.tv_sec + 1.e-6 * (float) resources.ru_utime.tv_usec;
    *stime = (float) resources.ru_stime.tv_sec + 1.e-6 * (float) resources.ru_stime.tv_usec;
    *total_time = *utime + *stime;
    //printf("%s%ld\n", buffer, tv.tv_usec);
}
