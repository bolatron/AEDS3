#ifndef PROTOTYPE_H_INCLUDED
#define PROTOTYPE_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <sys/resource.h>

// Estrutura de dado usada pra armazenar o tamanho maximo e posição da submatriz
// do guloso
typedef struct _GulosoDados {
    int altura_max;
    int pos_i, pos_j;
} GulosoData;

/* Funções de entrada e saída com arquivos da file.c */
int **leMatrizDeEntrada(char *arquivo, int *size);
void escreveMatrizSaida(int **arr, int size, char *arquivo);

/* Funções auxiliares da auxiliar.c */
int **geraMatrizAleatoria(int size, int seed);
void printaMatrizInt(int **arr, int size);
void printaMatrizfloat(float **arr, int size, int sizeM);
void printaTabela(int **arr, int size_i, int size_j);
void printaMaiorMatriz(int **arr, float **res_arr, int size_res, int size_mask);
void printaMaiorMatrizMascara(int **arr, float **res_arr, int size_res, int size_mask);
void printaMaiorMatrizGuloso(int **arr, int size, GulosoData data);
void printaMaiorMatrizDinamico(int **arr, int size, int **arr_res, int max_submatrix);
void liberaMatrizInt(int **arr, int size);
void liberaMatrizfloat(float **arr, int size);
int min(int a, int b, int c);
void SystemUsage(double *utime, double *stime, double *total_time);

/* Funções implementadas para achar a maior submatriz */
int achaMaiorMatrizPorMascara_Recursivo(int **arr, int sizeM, int size_mask);
int achaMaiorMatrizPorMascara_Iterativo(int **arr, int sizeM);
int achaMaiorMatrizPorGuloso(int **arr, int size);
int achaMaiorMatrizPorProgramacaoDinamica(int **arr, int size);
#endif
