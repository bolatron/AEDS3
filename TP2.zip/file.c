#include "prototype.h"

int **leMatrizDeEntrada(char *arquivo, int *size) {
    char c;
    int i, j;
    FILE *arq = fopen(arquivo, "r");
    while(fgetc(arq) != '\n')
        (*size)++;
    *size = *size / 2;
    fclose(arq);
    arq = fopen(arquivo, "r");
    int **arr = (int**) malloc((*size)*sizeof(int*));
    for(i=0; i < (*size); i++)
        arr[i] = (int*) malloc((*size)*sizeof(int));
    while(!feof(arq)){
        for(i=0; i < (*size); i++)
            for(j=0; j < (*size); j++)
                fscanf(arq, "%d", &arr[i][j]);
    }
    return arr;
}

void escreveMatrizSaida(int **arr, int size, char *arquivo){
    FILE *arq = fopen(arquivo, "w");
    int i, j;
    for(i=0; i < size; i++){
        for(j=0; j < size; j++)
            fprintf(arq, "%d ", arr[i][j]);
        fprintf(arq, "\r\n");
    }
    fclose(arq);
}
